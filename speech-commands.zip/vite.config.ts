import { defineConfig, loadEnv, ConfigEnv, UserConfig } from 'vite';

/** 配置项文档：https://cn.vitejs.dev/config */
export default defineConfig(({ command, mode }: ConfigEnv): UserConfig => {
  return {
    // 服务器选项
    server: {
      host: '0.0.0.0'
    }
  };
});
