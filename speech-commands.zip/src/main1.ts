import * as tf from '@tensorflow/tfjs';
import * as SpeechCommands from '@tensorflow-models/speech-commands';

const startButton = document.querySelector('#startBtn') as HTMLButtonElement;
const stopButton = document.querySelector('#stopBtn') as HTMLButtonElement;
const statusDiv = document.querySelector('#status') as HTMLDivElement;

let recognizer: SpeechCommands.SpeechCommandRecognizer;

async function init() {
  try {
    // 1. 设置 TensorFlow.js 后端
    await tf.setBackend('webgl');
    console.log('TensorFlow.js 后端:', tf.getBackend());

    // 2. 初始化语音命令识别器
    statusDiv.textContent = '正在初始化语音识别...';
    recognizer = SpeechCommands.create('BROWSER_FFT');

    // 3. 加载模型
    statusDiv.textContent = '正在加载语音模型...';
    await recognizer.ensureModelLoaded();

    // 4. 准备就绪
    startButton.disabled = false;
    statusDiv.textContent = '准备就绪，点击开始按钮说话';

    console.log('模型加载完成，支持的命令:', recognizer.wordLabels());
    statusDiv.textContent += `模型加载完成，支持的命令:${recognizer.wordLabels()}`;
  } catch (error) {
    console.error('初始化失败:', error);
    statusDiv.textContent = `初始化失败: ${(error as any).message}`;
    statusDiv.style.color = 'red';
  }
}

startButton.addEventListener('click', async () => {
  try {
    startButton.disabled = true;
    stopButton.disabled = false;
    statusDiv.textContent = '正在监听...请说话';

    await recognizer.listen(
      async result => {
        // 获取最可能的命令
        const scores = result.scores.map(Number);
        const maxScoreIndex = scores.indexOf(Math.max(...scores));
        const command = recognizer.wordLabels()[maxScoreIndex];

        console.log('识别结果:', command, '置信度:', scores[maxScoreIndex]);
        statusDiv.textContent = `识别到: ${command}`;
      },
      {
        includeSpectrogram: true,
        probabilityThreshold: 0.7,
        invokeCallbackOnNoiseAndUnknown: true
      }
    );
  } catch (error) {
    console.error('识别错误:', error);
    statusDiv.textContent = `识别错误: ${(error as any).message}`;
    statusDiv.style.color = 'red';
    startButton.disabled = false;
    stopButton.disabled = true;
  }
});

stopButton.addEventListener('click', async () => {
  try {
    await recognizer.stopListening();
    startButton.disabled = false;
    stopButton.disabled = true;
    statusDiv.textContent = '已停止，点击开始按钮说话';
  } catch (error) {
    console.error('停止失败:', error);
    statusDiv.textContent = `停止失败: ${(error as any).message}`;
    statusDiv.style.color = 'red';
  }
});

// 初始化应用
init();
